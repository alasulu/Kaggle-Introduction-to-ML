import pandas as pd

# To choose variables/columns, we'll need to see a list of all columns in the dataset. 
# That is done with the columns property of the DataFrame
df = pd.read_csv('melb_data.csv')
print(df.columns)

# The Melbourne data has some missing values (some houses for which some variables weren't recorded.)
# So we will take the simplest option for now, and drop houses from our data. 
df = df.dropna(axis=0)

# But we will focus on two approaches for now.
# Dot notation, which we use to select the "prediction target"
# Selecting with a column list, which we use to select the "features"

# You can pull out a variable with dot-notation. This single column is stored in a Series, 
# which is broadly like a DataFrame with only a single column of data.
# We'll use the dot notation to select the column we want to predict, which is 
# called the prediction target. By convention, the prediction target is called y. 
y = df.Price

# The columns that are inputted into our model (and later used to make predictions) 
# are called "features."
# We select multiple features by providing a list of column names inside brackets.
# Each item in that list should be a string (with quotes).
df_features = ['Rooms', 'Bathroom', 'Landsize', 'Lattitude', 'Longtitude']
# By convention, this data is called X.
X = df[df_features]
print(X.describe)
print(X.head(5)) # Only first 5 index

# You will use the scikit-learn library to create your models. When coding, this
# library is written as sklearn,
# The steps to building and using a model are:
#  - Define: What type of model will it be? A decision tree? Some other type of model? Some other parameters of the model type are specified too.
#  - Fit: Capture patterns from provided data. This is the heart of modeling.
#  - Predict: Just what it sounds like
#  - Evaluate: Determine how accurate the model's predictions are.
from sklearn.tree import DecisionTreeRegressor
df_model = DecisionTreeRegressor(random_state=1) # Define Model
print(df_model.fit(X,y)) # Model Fitting
# Specifying a number for random_state ensures you get the same results in each run. 
# We now have a fitted model that we can use to make predictions
print("Making predictions for the following 5 houses:")
print(X.head())
print("The predictions are")
print(df_model.predict(X.head()))