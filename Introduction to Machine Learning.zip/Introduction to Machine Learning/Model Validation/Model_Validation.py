# In this lesson, you will learn to use model validation to measure the quality 
# of your model. Measuring model quality is the key to iteratively improving your models.

# There are many metrics for summarizing model quality, but we'll start with one 
# called Mean Absolute Error (also called MAE). Let's break down this metric starting
# with the last word, error.
""" error-actual-predicted  is the prediction error for each house """
# With the MAE metric, we take the absolute value of each error. This converts 
# each error to a positive number. We then take the average of those absolute errors.

# Prepared Model

import pandas as pd
# Load data
melbourne_data = pd.read_csv('melb_data.csv') 
# Filter rows with missing price values
filtered_melbourne_data = melbourne_data.dropna(axis=0)
# Choose target and features
y = filtered_melbourne_data.Price
melbourne_features = ['Rooms', 'Bathroom', 'Landsize', 'BuildingArea', 
                        'YearBuilt', 'Lattitude', 'Longtitude']
X = filtered_melbourne_data[melbourne_features]
from sklearn.tree import DecisionTreeRegressor
# Define model
melbourne_model = DecisionTreeRegressor()
# Fit model
melbourne_model.fit(X, y)

# Here is how we calculate the mean absolute error:
from sklearn.metrics import mean_absolute_error
predicted_home_prices = melbourne_model.predict(X)
print(mean_absolute_error(y, predicted_home_prices))

# The measure we just computed can be called an "in-sample" score. We used a single 
# "sample" of houses for both building the model and evaluating it. Here's why this is bad.
# Imagine that, in the large real estate market, door color is unrelated to home price.
# The most straightforward way to do this is to exclude some data from the model-building 
# process, and then use those to test the model's accuracy on data it hasn't seen before. 
# This data is called "validation" data.

from sklearn.model_selection import train_test_split
# split data into training and validation data, for both features and target
# The split is based on a random number generator. Supplying a numeric value to
# the random_state argument guarantees we get the same split every time we
# run this script.
train_X, val_X, train_y, val_y = train_test_split(X, y, random_state = 0)
# Define model
melbourne_model = DecisionTreeRegressor()
# Fit model
melbourne_model.fit(train_X, train_y)
# get predicted prices on validation data
val_predictions = melbourne_model.predict(val_X)
print(mean_absolute_error(val_y, val_predictions))